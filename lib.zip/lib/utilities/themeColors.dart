import 'package:flutter/material.dart';

class ThemeColors {
  static Color green = Color(0xff38056e);
  static Color greenLight = Color(0xff38056e);
  static Color orange = Color(0xFFff7259);
}
