class ServerAddresses{
  static const serverAddress = 'http://ahmed453160-001-site1.etempurl.com';
  static const  register='/Accounts/Register';
  static const  Login='/Accounts/Login';
  static const UserHasAccount='/Accounts/UserHasAccount';
  static const OffersGetPaged='/Offers/GetPaged';
}